package itp265_FinalProject_stevengo;

/**
 * Description
 * @author Steven Gong
 * Assignment Details
 * Email: stevengo@usc.edu
 */
public interface AgeRestricted {
	public int getAgeLimit();
}
